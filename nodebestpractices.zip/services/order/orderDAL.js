"use strict";
var util = require('util'),
    configProvider = require('configProvider'),
    logger = require('logger');

class OrderDAL {
    constructor() {
        this.orders = "orders";
    }
    
    add(newOrder){
        
    }

}

module.exports = new OrderDAL();