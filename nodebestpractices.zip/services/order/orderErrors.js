/**
 * Created by yonatan on 1/3/2016.
 */

module.exports = {
    InvalidInput : "InvalidInput",
    OutdatedPricing : "OutdatedPricing",
    userNotEligible :"userNotEligible", 
    ResourceNotExist: "ResourceNotExist"
};
