'use strict';
module.exports.API = require('./orderAPI');
