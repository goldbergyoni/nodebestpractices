const lottery = require('./loto')
















































// console.log('Lets randomize a student');
// const myStudents = ['גרגורי מולדבסקי' , 'ניצן עזרא'];
// console.log('The following students participate:')
// myStudents.forEach((student) => {
//     console.log(`${reverse(student)},`)
// })
// const chosenStudentIndex = Math.floor(Math.random() * myStudents.length);
// console.log(chosenStudentIndex);
// console.log('***And the winner is:***')
// setTimeout(() => {console.log(reverse(myStudents[chosenStudentIndex]))}, 4000);

 