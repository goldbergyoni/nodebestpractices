class Startup {
    public static main(): number {
        let x :     number = 5;
        console.log('Hello World');
        return 0;
    }
}

Startup.main();