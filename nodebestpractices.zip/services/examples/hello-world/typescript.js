class Startup {
    static main() {
        console.log('Hello World');
        return 0;
    }
}
Startup.main();
