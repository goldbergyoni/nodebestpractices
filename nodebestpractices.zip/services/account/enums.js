

module.exports.roles = {
	User: 1,
	Admin: 64
};

module.exports.errors = {
	doesntExist : "doesntExist"
};
