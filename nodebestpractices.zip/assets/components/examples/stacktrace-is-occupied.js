console.log('Starting');

const startingDate = new Date();
setTimeout(function() {
    console.log(`After 50ms timeout, it took ${new Date() - startingDate}`) 
}, 50);

setTimeout(function() {
    console.log(`After 20ms timeout, it took ${new Date() - startingDate}`) 
}, 20);

console.log('Starting sync task');
while(new Date() - startingDate < 8000){

}
console.log('Ended the sync task');







//synchronous task that last few ms
// while(new Date() - startingDate < 8000){

// }



console.log('Ending');











// while(new Date() - startingDate < 50){
//     //starvation!
// }
// setImmediate(() => {console.log('immediate')})

// process.nextTick(() => {console.log('next tick')})
