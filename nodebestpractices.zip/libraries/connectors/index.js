'use strict';

module.exports = {
  salesforce: require('./salesforce')
};
