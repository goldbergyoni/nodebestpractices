﻿'use strict';

module.exports.service = require('./messageQueueService');
module.exports.helper = require('./messageQueueHelpers');
