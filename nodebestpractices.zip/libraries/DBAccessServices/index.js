'use strict';

module.exports.BaseDAL = require('./baseDAL');
