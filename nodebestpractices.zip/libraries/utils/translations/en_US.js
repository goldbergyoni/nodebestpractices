"use strict";

module.exports = {
  "UserProfile_AccountName": "Account Name",
  "UserProfile_ChangePassword": "Change Password",
  "UserProfile_Email": "Email",
  "UserProfile_FullName": "Full Name",
  "UserProfile_JobTitle": "Job Title",
  "UserProfile_Language": "Language",
  "UserProfile_Title": "My Profile",
  "UserProfile_UpdateProfile": "Update Profile"
};
