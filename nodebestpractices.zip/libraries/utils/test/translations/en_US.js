"use strict";

module.exports = {
  "test1": "test 1",
  "test2": "test 2",
  "test3": "test {0} {1} {0}"
};
