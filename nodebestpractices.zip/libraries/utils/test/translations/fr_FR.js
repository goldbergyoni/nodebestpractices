"use strict";

module.exports = {
  "test1": "test 1 fr"
};
