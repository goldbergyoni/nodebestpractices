# Title here

<br/><br/>


### One Paragraph Explainer

Text

<br/><br/>


### Code Example – explanation

```javascript
code here
```

<br/><br/>

### Code Example – another

```javascript
code here
```

<br/><br/>

### Blog Quote: "Title"
 From the blog pouchdb.com, ranked 11 for the keywords “Node Promises”
 
 > …text here

 <br/><br/>
 
 ### Image title
![alt text](https://github.com/i0natan/nodebestpractices/blob/master/assets/images/swaggerDoc.png "API error handling")

 
<br/><br/>
